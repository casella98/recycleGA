# Dialogflow webhook boilerplate node js (self-hosted)

## Open in Gitpod

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/anudeepreddy/dialogflow-webhook-boilerplate-nodejs)

## Development
```
> git clone https://github.com/anudeepreddy/dialogflow-webhook-boilerplate-nodejs
> cd dialogflow-webhook-boilerplate-nodejs
> npm install
> npm start
```

You should see the webhook running at URL : http://localhost:3000/webhook
